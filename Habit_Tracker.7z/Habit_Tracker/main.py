import json
import random
import logging
import string
import builtins
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Callable


class FileManager:
    """Handles file operations like loading and saving JSON data."""

    # Configure logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)

    @staticmethod
    def load_data(filename: str) -> List[Dict[str, Any]]:
        """
        Load data from a JSON file.

        Args:
            filename (str): The name of the JSON file to load.

        Returns:
            List[Dict[str, Any]]: The data loaded from the JSON file, or an empty list if an error occurs.
        """
        try:
            with open(filename, 'r') as file:
                data = json.load(file)
                FileManager.logger.info(f"Loaded data from {filename}")
                return data
        except FileNotFoundError:
            FileManager.logger.error(f"{filename} not found.")
            return []
        except json.JSONDecodeError as e:
            FileManager.logger.error(f"Error reading {filename}: {e}")
            return []

    @staticmethod
    def save_data(filename: str, data: List[Dict[str, Any]]):
        """
        Save data to a JSON file.

        Args:
            filename (str): The name of the JSON file to save.
            data (List[Dict[str, Any]]): The data to save.
        """
        try:
            with open(filename, 'w') as file:
                json.dump(data, file, indent=4)
                FileManager.logger.info(f"Saved data to {filename}")
        except IOError as e:
            FileManager.logger.error(f"Error writing to {filename}: {e}")


class Decoration:
    """
    Represents a decoration with states and experience points (EXP).

    Attributes:
        name (str): The name of the decoration.
        room (str): The room where the decoration is located.
        state (str): The current state of the decoration.
        exp (int): The current experience points of the decoration.
    """

    # EXP thresholds and corresponding states
    exp_states = {0: "Old", 16: "Normal", 32: "Good", 64: "Great"}

    # For filtering decorations
    decor_criteria_map = {
        'name': lambda decor: decor.name,
        'room': lambda decor: decor.room,
        'state': lambda decor: decor.state,
        'exp': lambda decor: decor.exp
    }

    def __init__(self, name: str, room: str, state: str, exp: int):
        self.name = name
        self.room = room
        self.state = state
        self.exp = exp

    def __repr__(self) -> str:
        return f"Decoration: {self.name}; Room: {self.room}; State: {self.state}; EXP: {self.exp}"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Decoration):
            return (self.name == other.name and
                    self.room == other.room and
                    self.state == other.state)
        return False

    def __hash__(self) -> int:
        return hash((self.name, self.room, self.state))

    def update_state(self):
        """
        Updates the state of the decoration based on its EXP.
        Logs the change and notifies the user if the state is upgraded or downgraded.
        """
        previous_state = self.state

        # Determine the new state based on current EXP
        for exp_threshold, state in sorted(Decoration.exp_states.items(), reverse=True):
            if self.exp >= exp_threshold:
                self.state = state
                break

        # If the state has changed, log the change and notify the user
        if self.state != previous_state:
            FileManager.logger.info(f"The decoration {self.name} was updated to {self.state}.")
            previous_state_index = list(Decoration.exp_states.values()).index(previous_state)
            new_state_index = list(Decoration.exp_states.values()).index(self.state)

            if new_state_index > previous_state_index:
                wrapped_message(f"Congratulations!"
                                f"\nThe decoration {self.name} was upgraded to {self.state} state!"
                                f"\nLooks better now!", 70)
            else:
                wrapped_message(f"The decoration {self.name} was downgraded to {self.state} state. "
                                f"\nDon't give up! Keep working to improve it!", 70)
            return


class Habit:
    """
    Represents a habit with a periodicity and associated decoration.

    Attributes:
        name (str): The name of the habit.
        periodicity (int): The periodicity of the habit (1=Daily, 2=Weekly, 3=Monthly, 4=Yearly).
        decoration (Decoration): The decoration associated with the habit.
        next_completion_date (datetime): The next date when the habit should be completed.
        fails (int): The number of times the habit has been missed.
        streak (int): The current streak of successful completions.
    """

    # EXP values based on periodicity
    exp_values = {1: 1, 2: 8, 3: 16, 4: 32}

    # Map periodicity numbers to words
    periodicity_map = {1: "Daily", 2: "Weekly", 3: "Monthly", 4: "Yearly"}

    # For displaying the habit tables
    habit_criteria_map = {
        'name': lambda habit: habit.name,
        'periodicity': lambda habit: habit.periodicity,
        'room': lambda habit: habit.decoration.room,
        'next_completion_date': lambda habit: habit.next_completion_date,
        'fails': lambda habit: habit.fails,
        'streak': lambda habit: habit.streak
    }

    def __init__(self, name: str, periodicity: int, decoration: Decoration,
                 next_completion_date: Optional[datetime] = None, fails: int = 0, streak: int = 0):
        self.name = name
        self.periodicity = periodicity
        self.decoration = decoration
        self.next_completion_date = next_completion_date or self.calculate_completion_date()
        self.fails = fails
        self.streak = streak

    def __repr__(self) -> str:
        return (f"Habit: {self.name}; Periodicity: {self.periodicity}; "
                f"Decoration: {self.decoration.name}; Room: {self.decoration.room}; "
                f"Check-in Day: {self.formatted_date}; Fails: {self.fails}; Streak: {self.streak}")

    @property
    def formatted_date(self) -> str:
        """Returns the formatted next completion date."""
        if self.next_completion_date:
            day_with_suffix = get_day_with_suffix(self.next_completion_date.day)
            return self.next_completion_date.strftime(f"%B {day_with_suffix}, %Y" if self.periodicity == 4 else f"%B {day_with_suffix}")
        return "N/A"

    def increment_completion_date(self, date: datetime) -> datetime:
        """Increments the provided date by the habit's periodicity."""
        if self.periodicity == 1:  # Daily
            return date + timedelta(days=1)
        elif self.periodicity == 2:  # Weekly
            return date + timedelta(weeks=1)
        elif self.periodicity == 3:  # Monthly
            return date.replace(month=(date.month % 12) + 1, year=date.year + (date.month // 12), day=min(date.day, 28))
        elif self.periodicity == 4:  # Yearly
            return date.replace(year=date.year + 1)
        raise ValueError("Invalid periodicity value.")

    def calculate_completion_date(self) -> datetime:
        """Calculates the next completion date based on the habit's periodicity."""
        return self.increment_completion_date(datetime.now())

    def calculate_fails(self) -> bool:
        """
        Calculates the number of fails based on the original next completion date and the current date.

        Returns:
            bool: True if fails were detected, False otherwise.
        """
        now = datetime.now()
        fails_detected = False

        while now > self.next_completion_date.replace(hour=23, minute=59, second=59):
            self.next_completion_date = self.increment_completion_date(self.next_completion_date)
            self.fails += 1
            fails_detected = True

        return fails_detected

    def check_in(self) -> bool:
        """
        Checks in the habit and updates streak or fails based on the completion date.

        Returns:
            bool: True if check-in was successful, False otherwise.
        """
        now = datetime.now()
        completion_date_start = self.next_completion_date.replace(hour=0, minute=0, second=0)
        completion_date_end = self.next_completion_date.replace(hour=23, minute=59, second=59)

        if now < completion_date_start:
            day_with_suffix = get_day_with_suffix(self.next_completion_date.day)
            formatted_date = self.next_completion_date.strftime(f"%B {day_with_suffix}")
            FileManager.logger.warning(f"Attempted early check-in for {self.name}.")
            wrapped_message(f"It's too early to check-in for {self.name}!"
                            f"\nPlease try again during this day: {formatted_date}.", 50)
            type_ok()
            return False

        if completion_date_start <= now <= completion_date_end:
            self.streak += 1
            self.decoration.exp += self.exp_values.get(self.periodicity, 0)
            FileManager.logger.info(f"Successfully checked in for {self.name}. "
                                    f"Streak: {self.streak}, EXP: {self.decoration.exp}.")

            self.decoration.update_state()

            self.next_completion_date = self.increment_completion_date(self.next_completion_date)
            FileManager.logger.debug(f"Next completion date for {self.name} set to {self.next_completion_date}.")
            wrapped_message(f"Successfully checked in for {self.name}!"
                            f"\nStreak: {self.streak}, EXP: {self.decoration.exp}."
                            f"\nYour next completion date is {self.formatted_date}."
                            f"\nMake sure to check in that day!", 50)
            type_ok()
            return True

        return False

    def reset_decoration(self):
        """Resets the decoration associated with this habit."""
        self.decoration.exp = 0
        self.decoration.state = "Old"
        FileManager.logger.info(f"Decoration '{self.decoration.name}' linked to habit '{self.name}' was reset.")
        print(f"The decoration '{self.decoration.name}' linked to habit '{self.name}' was reset and is now free!")


class Butler:
    """
    Represents a Butler with a name, age, appearance, and personality.

    Attributes:
        name (str): The Butler's name.
        age (int): The Butler's age.
        appearance (str): The Butler's appearance description.
        personality_flag (str): The flag representing the Butler's personality type.
        description (str): The description of the Butler's personality.
    """

    def __init__(self, name: str, age: int, appearance: str, personality_flag: str, description: str):
        self.name = name
        self.age = age
        self.appearance = appearance
        self.personality_flag = personality_flag
        self.description = description

    def __repr__(self) -> str:
        return (f"Butler: {self.name}; Age: {self.age}; Appearance: {self.appearance}; "
                f"Personality: {self.description}")

    @staticmethod
    def generate_butler(butler_options: Dict[str, Any]) -> 'Butler':
        """
        Generates a new Butler using options from the butler_options.json file.

        Args:
            butler_options (Dict[str, Any]): The options for generating a Butler.

        Returns:
            Butler: The generated Butler object.
        """
        name = random.choice(butler_options['names'])
        age = random.randint(21, 112)
        appearance = random.choice(butler_options['appearances'])
        personality_flag = random.choice(list(butler_options['personalities'].keys()))
        description = butler_options['personalities'][personality_flag]['description']

        new_butler = Butler(name, age, appearance, personality_flag, description)

        # Save the new butler to current_butler.json as a dictionary
        FileManager.save_data('current_butler.json', new_butler.__dict__)
        new_butler.display_info()

        return new_butler

    @staticmethod
    def quotes_and_tips() -> (str, str):
        """
        Retrieves a random motivational quote and tip.

        Returns:
            tuple: A random quote and a random tip.
        """
        random_quote = random.choice(quotes) if quotes else "\nNo quotes today. :("
        random_tip = random.choice(tips) if tips else "\nNo tips today. :("
        return random_quote, random_tip

    def talk_to(self, butler_options: Dict[str, Any]):
        """
        Generates a random replica based on the Butler's personality.

        Args:
            butler_options (Dict[str, Any]): The options for the Butler's replicas.
        """
        replicas = butler_options['personalities'][self.personality_flag]['replicas']
        wrapped_message(f"{self.name} says: {random.choice(replicas)}", 50)
        type_ok()

    def display_info(self):
        """Displays the Butler's information."""
        wrapped_message("Here's your Butler's information:", 50)
        print(f"Name: {self.name}\nAge: {self.age}"
              f"\nAppearance: {self.appearance}\nPersonality: {self.description}")
        type_ok()

    def check_progress(self, habit_objects: List[Habit]):
        """
        Displays the user's progress in terms of streaks and fails.

        Args:
            habit_objects (List[Habit]): The list of habits to check progress for.
        """
        if empty_list(habit_objects):
            return

        total_streaks = sum(habit.streak for habit in habit_objects)
        total_fails = sum(habit.fails for habit in habit_objects)
        habit_most_streaks = max(habit_objects, key=lambda habit: habit.streak, default=None)
        habit_most_fails = max(habit_objects, key=lambda habit: habit.fails, default=None)

        wrapped_message(f"You have in total {total_streaks} streaks and {total_fails} fails.", 50)

        if habit_most_streaks and habit_most_streaks.streak > 0:
            print(f"\nYour habit {habit_most_streaks.name} has the record of {habit_most_streaks.streak} streaks."
                f"\nWell done!")
        if habit_most_fails and habit_most_fails.fails > 0:
            print(f"\nYour habit {habit_most_fails.name} has the most fails: {habit_most_fails.fails}."
                  f"\nDon't get discouraged; perhaps you can rethink your approach?")

        type_ok()


class Conversion:
    """Handles conversion between JSON data and Python objects."""

    rooms = ["Living Room", "Bedroom", "Home Office"]
    decor_names = ["Sofa", "Armchair", "Coffee Table", "Rug", "Pillow"]

    @staticmethod
    def serialize_habits(habit_objects: List[Habit]) -> List[Dict[str, Any]]:
        """
        Converts a list of Habit objects into a serializable format for JSON.

        Args:
            habit_objects (List[Habit]): The list of Habit objects to serialize.

        Returns:
            List[Dict[str, Any]]: The serialized habit data.
        """
        serialized_habits = []
        for habit in habit_objects:
            habit_dict = habit.__dict__.copy()
            if habit_dict['next_completion_date']:
                habit_dict['next_completion_date'] = habit_dict['next_completion_date'].isoformat()
            if isinstance(habit_dict['decoration'], Decoration):
                habit_dict['decoration'] = habit_dict['decoration'].__dict__
            serialized_habits.append(habit_dict)
        return serialized_habits

    @staticmethod
    def convert_habit(habit_data: Dict[str, Any]) -> Habit:
        """
        Converts a dictionary from JSON into a Habit object.

        Args:
            habit_data (Dict[str, Any]): The habit data from JSON.

        Returns:
            Habit: The converted Habit object.
        """
        corrupted_fields = []

        # Handle next_completion_date
        try:
            if 'next_completion_date' in habit_data and habit_data['next_completion_date']:
                habit_data['next_completion_date'] = datetime.fromisoformat(habit_data['next_completion_date'])
            else:
                raise KeyError('next_completion_date')
        except (KeyError, ValueError):
            habit_data['next_completion_date'] = None
            corrupted_fields.append('next_completion_date')

        # Handle missing name
        if 'name' not in habit_data or not habit_data['name']:
            habit_data['name'] = random.choice(string.ascii_letters)
            corrupted_fields.append('name')

        # Handle missing periodicity
        if 'periodicity' not in habit_data or not habit_data['periodicity']:
            habit_data['periodicity'] = 1
            corrupted_fields.append('periodicity')

        # Handle missing decoration
        if 'decoration' in habit_data and isinstance(habit_data['decoration'], dict):
            matched_decor = next((decor for decor in decor_objects if
                                  decor.name == habit_data['decoration']['name'] and
                                  decor.room == habit_data['decoration']['room'] and
                                  decor.state == habit_data['decoration']['state']), None)

            habit_data['decoration'] = matched_decor if matched_decor else Conversion.convert_decor(habit_data['decoration'])
        else:
            habit_data['decoration'] = random.choice(decor_objects) if decor_objects else None
            corrupted_fields.append('decoration')

        current_habit = Habit(**habit_data)

        if corrupted_fields:
            corrupted_data.append(f"Habit '{current_habit.name}': changed fields - {', '.join(corrupted_fields)}")

        return current_habit

    @staticmethod
    def convert_decor(decor_data: Dict[str, Any]) -> Decoration:
        """
        Converts a decoration dictionary from JSON into a Decoration object with default values for missing attributes.

        Args:
            decor_data (Dict[str, Any]): The decoration data from JSON.

        Returns:
            Decoration: The converted Decoration object.
        """
        corrupted_fields = []

        # Handle missing name
        if 'name' not in decor_data or not decor_data['name']:
            decor_data['name'] = random.choice(Conversion.decor_names)
            corrupted_fields.append('name')

        # Handle missing room
        if 'room' not in decor_data or not decor_data['room']:
            decor_data['room'] = random.choice(Conversion.rooms)
            corrupted_fields.append('room')

        # Handle missing state
        if 'state' not in decor_data or not decor_data['state']:
            decor_data['state'] = "Old"
            corrupted_fields.append('state')

        # Handle missing exp
        if 'exp' not in decor_data:
            decor_data['exp'] = 0
            corrupted_fields.append('exp')

        decoration = Decoration(**decor_data)

        if corrupted_fields:
            corrupted_data.append(f"Decoration '{decoration.name}': changed fields - {', '.join(corrupted_fields)}")

        return decoration


def saving():
    """Save the current state of habits and decorations to their respective JSON files."""
    FileManager.save_data('habits.json', Conversion.serialize_habits(habit_objects))
    FileManager.save_data('decorations.json', [decor.__dict__ for decor in decor_objects])


# Save the original input function
original_input = builtins.input

def custom_input(prompt: str) -> str:
    """Custom input function that returns to the main menu if the user types 'x'."""
    user_input = original_input(prompt).strip().lower()
    if user_input == 'x':
        print("Returning to main menu...")
        main_menu()
    return user_input

# Override the built-in input function
builtins.input = custom_input


def type_ok():
    """Prompts the user to type 'OK' to continue."""
    while True:
        choice = input("\nType 'OK' to continue: ").strip().upper()
        if choice == "OK":
            break
        else:
            print("\nDude, come on. Type OK to continue.")


def wrapped_message(message: str, width: int = 30):
    """Prints a message wrapped in lines of '='."""
    print("\n" + "=" * width)
    print(message.center(width))  # Center the message within the wrapper
    print("=" * width)


def get_day_with_suffix(day: int) -> str:
    """Returns the day of the month with the appropriate suffix."""
    if 11 <= day <= 13:
        suffix = 'th'
    else:
        suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(day % 10, 'th')
    return f"{day}{suffix}"


def choice_check(number: int) -> int:
    """Prompt the user to enter a valid number within a specified range."""
    while True:
        try:
            choice = int(input(f"\nPlease enter a number between 1 and {number}: "))
            if 1 <= choice <= number:
                return choice
            else:
                FileManager.logger.warning(f"Invalid input: {choice}. Expected a number between 1 and {number}.")
                print(f"\nInvalid input. Please enter a number between 1 and {number}.")
        except ValueError:
            FileManager.logger.warning(f"Invalid input. Expected a number between 1 and {number}.")
            print(f"Invalid input. Please enter a number between 1 and {number}.")


def empty_list(current_list: List[Any]) -> bool:
    """Check if the list is empty and print a message if it is."""
    if not current_list:
        wrapped_message("Sorry, but this list is empty! Returning...", 50)
        return True
    return False


def giving_list(items: List[Any]) -> bool:
    """Print a numbered list of items with specific formatting for Habits and Decorations."""
    if empty_list(items):
        return False

    # Determine the maximum width for each column
    max_name_len = max(len(getattr(item, 'name', '')) for item in items) + 2
    max_date_len = max(len(getattr(item, 'formatted_date', 'N/A')) for item in items) + 2
    number_width = len(str(len(items)))  # This gives the width of the largest number

    # Print the list with alignment
    for i, thing in enumerate(items, start=1):
        if isinstance(thing, Habit):
            periodicity_str = Habit.periodicity_map.get(thing.periodicity, "Unknown")
            print(f"{str(i).rjust(number_width)}. {thing.name.ljust(max_name_len)} | "
                  f"{periodicity_str.ljust(7)} | "
                  f"Decoration: {thing.decoration.name.ljust(max_name_len)} | "
                  f"Next Completion Date: {thing.formatted_date.ljust(max_date_len)} | "
                  f"Streak: {thing.streak} | "
                  f"{thing.fails} Fails")
        elif isinstance(thing, Decoration):
            print(f"{str(i).rjust(number_width)}. {thing.name.ljust(max_name_len)} | "
                  f"{thing.room.ljust(13)} | "
                  f"{thing.state.ljust(7)} | "
                  f"{str(thing.exp)} EXP")
        else:
            print(f"{i}. {thing}")  # Default printing for any other object type

    return True


def view_items(items: List[Any], criteria_map: Dict[str, Callable[[Any], Any]], is_habit: bool = False, action: Optional[str] = None):
    """View all items (habits or decorations) and allow editing, deletion, filtering, or other actions."""
    if not giving_list(items):
        return

    if action == "check_in" and is_habit:
        print("\nFirst, let's choose what to check-in!")
        choice = choice_check(len(items))
        items[choice - 1].check_in()
        saving()
        return

    while True:
        # Display appropriate options based on item type
        if is_habit:
            print("\nWhat would you like to do now?"
                  "\n1. Edit/Delete a certain habit"
                  "\n2. Filter habits by a criterion..."
                  "\n3. Go back")
            sub_choice = choice_check(3)
        else:
            print("\nWhat would you like to do now?"
                  "\n1. Filter decorations by a criterion..."
                  "\n2. Go back")
            sub_choice = choice_check(2)

        if is_habit and sub_choice == 1:
            if len(items) == 1:
                # If there's only one habit, directly proceed to edit/delete it
                edit_habit(items[0])
            else:
                print("\nWhat habit are you interested in?")
                choice = choice_check(len(items))
                edit_habit(items[choice - 1])
        elif (is_habit and sub_choice == 2) or (not is_habit and sub_choice == 1):
            filter_items_menu(items, criteria_map)
        else:
            break

        saving()


def filter_items(items: List[Any], criterion: str, criteria_map: Dict[str, Callable[[Any], Any]]) -> List[Any]:
    """Filters and sorts the list of items based on the given criterion."""
    if criterion not in criteria_map:
        raise ValueError("Invalid criterion.")

    reverse = criterion in ['fails', 'streak', 'exp']  # Reverse order for certain criteria

    return sorted(items, key=criteria_map[criterion], reverse=reverse)


def filter_items_menu(items: List[Any], criteria_map: Dict[str, Callable[[Any], Any]]):
    """Filter and display items based on a chosen criterion."""
    if empty_list(items):
        return

    while True:
        print(f"\nHere's your available criteria: {', '.join(criteria_map.keys())}")

        criterion = input("Please type the chosen criterion: ").strip().lower()

        try:
            filtered_items = filter_items(items, criterion, criteria_map)
            break  # Exit the loop if the criterion is valid
        except ValueError as e:
            print(f"\n{e}")

    wrapped_message(f"Here's a list of your items, filtered by {criterion}:", 70)
    giving_list(filtered_items)


def create_new_habit():
    """Creates a new habit and adds it to the JSON file."""
    wrapped_message("CREATING A HABIT", 50)
    print("Let's go! First, please choose a decoration from the list.")
    giving_list(decor_objects)
    choice = choice_check(len(decor_objects))
    decoration = decor_objects[choice - 1]

    # Perform the decor_check
    if not decor_check(decoration, habit_objects):
        print("\nHabit creation canceled.")
        return  # Stop here without calling main_menu or saving

    name = get_habit_name()
    periodicity = get_periodicity()

    next_completion_date = None
    new_habit = Habit(name, periodicity, decoration, next_completion_date, fails=0, streak=0)
    new_habit.decoration.exp = 0
    habit_objects.append(new_habit)
    saving()

    print(
        f"\nYour new habit, {new_habit.name}, is created! "
        f"\nDon't forget to check in on this day: {new_habit.formatted_date}!")
    type_ok()


def get_habit_name() -> str:
    """Prompt the user for a habit name and ensure it is less than 32 characters."""
    name = input("\nWhat's the name of the habit? ")
    while len(name) > 32:
        FileManager.logger.warning("Invalid habit name length. Expected less than 32 characters.")
        name = input("\nInvalid input. Please make the name less than 32 characters long.")
    return name


def get_periodicity() -> int:
    """Prompt the user to select the periodicity of the habit."""
    print("\nWhat's the periodicity?"
          "\n1. Daily"
          "\n2. Weekly"
          "\n3. Monthly"
          "\n4. Yearly")
    return choice_check(4)


def decor_check(decoration: Decoration, habit_objects: List[Habit], current_habit: Optional[Habit] = None) -> bool:
    """Check if the decoration is already linked to another habit."""
    for habit in habit_objects:
        if habit.decoration == decoration and habit != current_habit:
            print(f"\nWARNING: Decoration {decoration.name} is already linked to the habit {habit.name}!"
                  "\nChoosing it will delete the existing habit and EXP, creating a new one.")
            while True:
                proceed = input("\nDo you want to proceed? (yes/no): ").strip().lower()
                if proceed in ['yes', 'no']:
                    if proceed == 'yes':
                        habit_objects.remove(habit)  # Delete the existing habit
                        print(f"\nThe habit '{habit.name}' has been deleted.")
                    return proceed == 'yes'
                else:
                    FileManager.logger.warning("Invalid input. Expected 'yes' or 'no'.")
                    print("Invalid input. Please type 'yes' or 'no'.")
    return True


def edit_habit(habit: Habit) -> None:
    """Allows the user to edit the habit's information."""
    options = {
        1: "Name",
        2: "Periodicity",
        3: "Decoration",
        4: "Delete this habit"
    }

    print("\nWhat would you like to change?")
    for key, value in options.items():
        print(f"{key}. {value}")

    choice = choice_check(len(options))

    if choice == 1:
        habit.name = get_habit_name()
        print(f"\nThe name of the habit has been updated to '{habit.name}'!")

    elif choice == 2:
        habit.periodicity = get_periodicity()
        habit.next_completion_date = habit.calculate_completion_date()
        habit.fails = 0
        habit.streak = 0
        print(f"\nAfter changing periodicity, your fails and streaks are now set to 0!"
              f"\nYour new next completion date is {habit.formatted_date}.")

    elif choice == 3:
        habit.reset_decoration()
        print("\nPlease enter the number of the decoration you're interested in.")
        if giving_list(decor_objects):
            decoration_choice = choice_check(len(decor_objects))
            decoration = decor_objects[decoration_choice - 1]
            if decor_check(decoration, habit_objects, current_habit=habit):
                habit.decoration = decoration
                habit.decoration.exp = 0  # Reset the new decoration's EXP
                print(f"\nDecoration for habit '{habit.name}' has been updated, EXP reset to 0!")
            else:
                print("\nDecoration change canceled.")

    elif choice == 4:
        habit.reset_decoration()
        habit_objects.remove(habit)
        print(f"This habit '{habit.name}' was deleted!")

    saving()
    type_ok()


def delete_habits():
    """Deletes all current habits, clearing the habit_objects list."""
    global habit_objects  # Ensure we're modifying the global habit_objects list
    for habit in habit_objects:
        habit.reset_decoration()  # Reset decorations before deleting habits
    habit_objects = []  # Clear the list
    wrapped_message("All habits and their linked decorations have been deleted and reset!", 70)
    saving()  # Save the updated (empty) list to the JSON file
    return

def handle_check_in():
    """Handle the check-in process for habits."""
    if empty_list(habit_objects):
        return

    wrapped_message("LET'S CHECK IN!", 30)
    if len(habit_objects) == 1:
        # If there's only one habit, automatically start check-in
        habit_objects[0].check_in()
    else:
        # If there's more than one habit, display the habits and ask for choice
        view_items(habit_objects, Habit.habit_criteria_map, is_habit=True, action="check_in")

    saving()


def butler_menu():
    """Display the butler menu with options to view, hire, or talk to the butler."""
    global butler

    # If no Butler exists, generate a new one
    if not butler:
        wrapped_message("Looks like your Butler went missing! "
                        "Keep calm, the Agency is sending a new one...", 80)
        butler = Butler.generate_butler(butler_options)

    while True:
        wrapped_message("THE BUTLER IS HERE!", 30)
        print("They will help you learn more about your progress.")

        print("What would you like to do?"
              "\n\n== YOUR BUTLER =="
              "\n1. About them"
              "\n2. Chit-chat"
              "\n3. Hire a new one"
              "\n\n== YOUR PROGRESS =="
              "\n4. Ask about my progress (streaks and fails)"
              "\n5. Get a motivational quote and a tip"
              "\n6. Go back")
        choice = choice_check(6)

        if choice == 1:
            butler.display_info()
        elif choice == 2:
            butler.talk_to(butler_options)
        elif choice == 3:
            wrapped_message("You fired the previous Butler! The Agency sent you a new one.", 70)
            butler = Butler.generate_butler(butler_options)
        elif choice == 4:
            butler.check_progress(habit_objects)
        elif choice == 5:
            random_quote, random_tip = butler.quotes_and_tips()
            wrapped_message(f"MOTIVATIONAL QUOTE: {random_quote} \nTIP OF THE DAY: {random_tip}", 100)
            type_ok()
        elif choice == 6:
            break


def main_menu():
    """Display the main menu and handle user navigation."""
    while True:
        wrapped_message("MAIN MENU", 50)
        print("Please type valid numbers to navigate the app."
              "\nType X at any point to return back to the main menu.")
        print("\n== HABITS =="
              "\n1. Check-in!"
              "\n2. Create a new habit"
              "\n3. View all your habits"
              "\n4. Delete all your habits"
              "\n\n== PALACE =="
              "\n5. Check the palace's rooms"
              "\n6. Check decorations"
              "\n\n== BUTLER =="
              "\n7. Talk to the Butler"
              "\n\n== OTHER =="
              "\n8. Exit the app")
        choice = choice_check(8)

        if choice == 1:
            handle_check_in()
        elif choice == 2:
            create_new_habit()
        elif choice == 3:
            if habit_objects:
                wrapped_message("Here's a list of your habits:", 55)
            view_items(habit_objects, Habit.habit_criteria_map, is_habit=True)
        elif choice == 4:
            delete_habits()
            type_ok()
        elif choice == 5:
            wrapped_message("Here's a list of all the rooms in your palace:", 50)
            giving_list(Conversion.rooms)
            type_ok()
        elif choice == 6:
            wrapped_message("Here's a list of your decorations:", 55)
            view_items(decor_objects, Decoration.decor_criteria_map, is_habit=False)
        elif choice == 7:
            butler_menu()
        elif choice == 8:
            saving()
            exit()


# Initialize lists to keep track of corrupted data and fails
corrupted_data = []
failed_habits = []

# Load and convert data
decor_objects = [Conversion.convert_decor(decor) for decor in FileManager.load_data('decorations.json')]
habit_objects = [Conversion.convert_habit(habit) for habit in FileManager.load_data('habits.json')]

# Load Butler data
butler_options = FileManager.load_data('butler_options.json')
current_butler_data = FileManager.load_data('current_butler.json')
tips = FileManager.load_data('tips.json')
quotes = FileManager.load_data('quotes.json')

# Initialize Butler object
butler = None
if current_butler_data:
    if isinstance(current_butler_data, list) and len(current_butler_data) > 0:
        current_butler_data = current_butler_data[0]  # Take the first element if it's a list
    if isinstance(current_butler_data, dict):
        butler = Butler(**current_butler_data)
    else:
        butler = None  # No Butler yet
else:
    butler = None  # No Butler yet

# Check for failed habits only if the current time is past the end of the check-in day
for habit in habit_objects:
    original_fails = habit.fails
    completion_date_end = habit.next_completion_date.replace(hour=23, minute=59, second=59)

    # Only mark as failed if current time is past the end of the allowed check-in time
    if datetime.now() > completion_date_end:
        if habit.calculate_fails() and habit.fails > original_fails:
            failed_habits.append(habit)

            # Deduct EXP for each fail
            for _ in range(habit.fails - original_fails):  # Deduct for each new fail
                deduction = habit.exp_values.get(habit.periodicity, 0) / 2
                habit.decoration.exp = max(habit.decoration.exp - deduction, 0)
                habit.decoration.update_state()  # Update the decoration state after deduction

# Start the app
print("\nWelcome to the Habit Tracker!")

if corrupted_data:
    wrapped_message("Unfortunately, some data was corrupted. We had to change certain habits/decorations."
          "\nHere are the changes: ", 50)
    giving_list(corrupted_data)

if failed_habits:
    wrapped_message("Unfortunately, you failed the following habits since the last time: ", 50)
    giving_list(failed_habits)
    print("\nDon't get upset. You got this!")
    type_ok()

main_menu()
saving()